// function formattime(str){
// 	var y = str.getFullYear()
// 	var m = str.getMonth() + 1
// 	var d = str.getDate()
// 	var hh = str.getHours()
// 	var mm = str.getMinutes()
// 	var ss = str.getSeconds()
// 	hh = hh < 10 ? '0' + hh : hh
// 	mm = mm < 10 ? '0' + mm : mm
// 	ss = ss < 10 ? '0' + ss : ss
// 	return `${y}-${m}-${d} ${hh}:${mm}:${ss}`
// }
// module.exports = {
// 	formattime: formattime
// }